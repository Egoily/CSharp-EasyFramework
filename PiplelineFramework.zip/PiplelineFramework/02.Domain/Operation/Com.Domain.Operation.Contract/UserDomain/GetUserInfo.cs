﻿using System;
using System.Runtime.Serialization;
using Com.Domain.CoreModel.UserDomain;
using Com.Domain.Operation.Contract.DtoModel;
using Com.Framework.Model.Operation.Messages;

namespace Com.Domain.Operation.Contract.UserDomain
{

    /// <summary>
    /// 
    /// </summary>
    [DataContract(Namespace = Declarations.NameSpace)]
    [Serializable]
    public class GetUserInfoReq : BaseRequest
    {
        [DataMember]
        public string UserId { get; set; }

    }
    /// <summary>
    /// 
    /// </summary>
    [DataContract(Namespace = Declarations.NameSpace)]
    [Serializable]
    public class GetUserInfoRes : BaseResponse
    {
        [DataMember]
        public UserInfo User { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>

    [Serializable]
    public class GetUserInfoReqCore : BaseRequest
    {
        public string UserId { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>


    [Serializable]
    public class GetUserInfoResCore : BaseResponse
    {
        public User User { get; set; }
    }


}
