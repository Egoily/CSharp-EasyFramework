﻿using System;
using System.Reflection;
using Com.Domain.CoreModel.UserDomain;
using Com.Domain.Operation.Contract.DtoModel;
using Com.Domain.Operation.Contract.UserDomain;
using Com.Framework.Contract;
using Com.Framework.Infrastructure;
using Com.Framework.Model.Operation.Messages;
using Com.Framework.Operation;
using Com.Domain.Operation.Mapping;

namespace Com.Domain.Operation.Impl.UserDomain
{

    public class GetUserInfoBizOp : AbstractBasicBizOp<GetUserInfoReq, GetUserInfoRes, GetUserInfoReqCore, GetUserInfoResCore>
    {

        public override string OperationDiscriminator => MethodBase.GetCurrentMethod().DeclaringType?.Name.Replace("BizOp", "");


        protected override void Inbound(GetUserInfoReq request, ref GetUserInfoReqCore coreInput)
        {
            coreInput = DtoConverter.Convert(request);
        }
        protected override GetUserInfoResCore ProcessBusinessLogic(GetUserInfoReqCore request, Invokation invoker)
        {

            var response = DefaultMessage<GetUserInfoResCore>.GenerateDefault();

            response.User = new User()
            {
                UserId = request.UserId,
                UserName = $"fake user name of {request.UserId}"
            };
            //TODO:
            response = DefaultMessage<GetUserInfoResCore>.GenerateOkResponse(response);

            return response;
        }

        protected override void Outbound(GetUserInfoResCore coreOutput,ref  GetUserInfoRes response)
        {
            response = DtoConverter.Convert(coreOutput);
        }


    }









}
