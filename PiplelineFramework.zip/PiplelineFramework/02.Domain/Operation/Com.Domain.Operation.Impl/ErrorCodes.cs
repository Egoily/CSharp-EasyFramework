﻿using System;

namespace Com.Domain.Operation.Impl
{
    public static class ErrorCodes
    {
        public const Int32 ErrorBase = 1000;

        /// <summary>
        /// 
        /// </summary>
        public const Int32 Unauthorized = ErrorBase + 1;
        /// <summary>
        /// 无效的请求
        /// </summary>
        public const Int32 InvalidRequest = ErrorBase + 2;
        /// <summary>
        /// 操作失败
        /// </summary>
        public const Int32 OperationFailed = ErrorBase + 3;

        /// <summary>
        /// 没有权限访问
        /// </summary>
        public const Int32 NoPermission = ErrorBase + 4;

        /// <summary>
        /// 空对象
        /// </summary>
        public const Int32 NullObject = ErrorBase + 5;

        /// <summary>
        /// 无效的对象
        /// </summary>
        public const Int32 InvalidObject = ErrorBase + 6;

        /// <summary>
        /// 找不到的对象
        /// </summary>
        public const Int32 NotFoundObject = ErrorBase + 7;

        /// <summary>
        /// 已存在的对象
        /// </summary>
        public const Int32 ExistedObject = ErrorBase + 8;

        /// <summary>
        /// 已被使用的对象
        /// </summary>
        public const Int32 UsedObject = ErrorBase + 9;

        /// <summary>
        /// 过期的对象
        /// </summary>
        public const Int32 ExpiredObject = ErrorBase + 10;
        /// <summary>
        /// 重复的对象
        /// </summary>
        public const Int32 RepeatedObject = ErrorBase + 11;

        /// <summary>
        /// 禁用的
        /// </summary>
        public const Int32 DisabledObject = ErrorBase + 12;

        /// <summary>
        /// 已达上限
        /// </summary>
        public const Int32 OverMax = ErrorBase + 13;

        /// <summary>
        /// 低于下限
        /// </summary>
        public const Int32 UnderMin = ErrorBase + 14;
    }
}
