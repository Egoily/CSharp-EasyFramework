﻿namespace Com.Domain.Operation.Mapping
{

    /// <summary>
    ///  Custom Type Converters
    /// </summary>
    public class CustomTypeConverters
    {
      
    
    }
}
