﻿using AutoMapper;
using Com.Domain.CoreModel.UserDomain;
using Com.Domain.Operation.Contract.DtoModel;
using Com.Domain.Operation.Contract.UserDomain;

namespace Com.Domain.Operation.Mapping
{
    /// <summary>
    /// 
    /// </summary>
    public static class DtoConverter
    {
        public static UserInfo Convert(User source)
        {
            return Mapper.Map<UserInfo>(source);
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static GetUserInfoReqCore Convert(GetUserInfoReq source)
        {
            return AutoMapper.Mapper.Map<GetUserInfoReqCore>(source);
        }


        public static GetUserInfoRes Convert(GetUserInfoResCore source)
        {
            var destination = AutoMapper.Mapper.Map<GetUserInfoRes>(source);

            return destination;
        }


    }
}
