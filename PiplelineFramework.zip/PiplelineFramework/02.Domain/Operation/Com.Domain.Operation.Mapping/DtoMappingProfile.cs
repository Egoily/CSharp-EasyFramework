﻿using AutoMapper;
using Com.Domain.CoreModel.UserDomain;
using Com.Domain.Operation.Contract.DtoModel;
using Com.Domain.Operation.Contract.UserDomain;

namespace Com.Domain.Operation.Mapping
{
    public class DtoMappingProfile : Profile
    {
        public DtoMappingProfile()
        {
            ProfileConfigure();
        }
        private void ProfileConfigure()
        {
            #region Custom type converter

            #endregion


            CreateMap<User, UserInfo>()
                ;


            CreateMap<GetUserInfoReq, GetUserInfoReqCore>()
               ;
            CreateMap<GetUserInfoResCore, GetUserInfoRes>()
               ;

        }
    }
}