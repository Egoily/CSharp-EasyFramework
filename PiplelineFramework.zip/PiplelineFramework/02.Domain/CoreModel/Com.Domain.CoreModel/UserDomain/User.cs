﻿using System;

namespace Com.Domain.CoreModel.UserDomain
{
    [Serializable]
    public class User : ICloneable
    {
        public string UserId { get; set; }
        public string UserName { get; set; }

        public object Clone()
        {
            return MemberwiseClone();
        }
    }
}
