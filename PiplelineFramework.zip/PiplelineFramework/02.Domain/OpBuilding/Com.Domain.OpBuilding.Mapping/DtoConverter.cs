﻿using AutoMapper;

namespace Com.Domain.OpBuilding.Mapping
{
    /// <summary>
    /// 
    /// </summary>
    public static class DtoConverter
    {
        public static Com.Domain.OpBuilding.Contract.DtoModel.UserInfo Convert(Com.Domain.Operation.Contract.DtoModel.UserInfo source)
        {
            return Mapper.Map<Com.Domain.OpBuilding.Contract.DtoModel.UserInfo>(source);
        }




    }
}
