﻿using AutoMapper;
using Com.Domain.OpBuilding.Contract.UserDomain;
using Com.Domain.Operation.Contract.UserDomain;

namespace Com.Domain.OpBuilding.Mapping
{

    /// <summary>
    /// 
    /// </summary>
    public class ContractProfile : Profile
    {

        public ContractProfile()
        {
            ProfileConfigure();
        }
        /// <summary>
        /// 
        /// </summary>
        private void ProfileConfigure()
        {
            #region Custom type converter

            #endregion


            CreateMap<GetUserInfoRequest, GetUserInfoReq>()
            ;
            CreateMap<GetUserInfoRes, GetUserInfoResponse>()
            .ForMember(dest => dest.User, opt => opt.Ignore())
            ;

 
            CreateMap<Com.Domain.Operation.Contract.DtoModel.UserInfo, Com.Domain.OpBuilding.Contract.DtoModel.UserInfo>()
            ;

        }
    }
}