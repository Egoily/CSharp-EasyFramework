﻿using System;
using AutoMapper;

namespace Com.Domain.OpBuilding.Mapping
{

    /// <summary>
    ///  Custom Type Converters
    /// </summary>
    public class CustomTypeConverters
    {
      
    
    }
}
