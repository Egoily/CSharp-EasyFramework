﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.Domain.OpBuilding.Infrastructure;
using Com.Framework.Infrastructure;
using Com.Framework.Pipeline.Builders;
using Com.Domain.OpBuilding.Contract.UserDomain;
using Com.Domain.Operation.Contract.UserDomain;
using Com.Framework.Contract;
using Com.Domain.Operation.Impl.UserDomain;
using Com.Framework.Model.Operation.Messages;


namespace Com.Domain.OpBuilding.Processors
{
    public class Processor
    {

    }
}
