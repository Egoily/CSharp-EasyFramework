﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.Domain.OpBuilding.Infrastructure;
using Com.Framework.Pipeline.Builders;
using Com.Domain.OpBuilding.Contract.UserDomain;
using Com.Domain.OpBuilding.Mapping;
using Com.Domain.Operation.Contract.UserDomain;
using Com.Framework.Contract;
using Com.Domain.Operation.Impl.UserDomain;
using Com.Framework.Infrastructure;
using Com.Framework.Model.Operation.Messages;
using Com.Framework.Operation;


namespace Com.Domain.OpBuilding.Processors
{
    public class GetUserInfoProcessor : Processor
    {
        public class Validator : BaseValidator<GetUserInfoRequest>
        {
            public override bool Validate(GetUserInfoRequest request, List<string> messages)
            {
                //TODO:
                if (string.IsNullOrEmpty(request.UserId))
                {
                    messages.Add("UserId must be not null");
                }
                return base.Validate(request, messages);
            }
        }
        public class AuthorizeValidator : BaseValidator<GetUserInfoRequest>
        {
            public override bool Validate(GetUserInfoRequest request, List<string> messages)
            {
                //TODO:
                if (string.IsNullOrEmpty(request.UserId))
                {
                    messages.Add("UserId must be not null");
                }
                return base.Validate(request, messages);
            }

            public override bool Authorize(Credential credential, string message)
            {
                if (credential == null || credential.UserName != "Ego" || credential.Password != "1234")
                {
                    message = "Unauthorized";
                }
                return base.Authorize(credential, message);
            }
        }


        public class Converter : ITypeConverter<GetUserInfoRequest, GetUserInfoReq>, ITypeConverter<GetUserInfoRes, GetUserInfoResponse>
        {
            /// <summary>
            /// 
            /// </summary>
            /// <param name="source"></param>
            /// <returns></returns>
            public GetUserInfoReq Convert(GetUserInfoRequest source)
            {
                return AutoMapper.Mapper.Map<GetUserInfoReq>(source);
            }


            public GetUserInfoResponse Convert(GetUserInfoRes source)
            {
                var destination = AutoMapper.Mapper.Map<GetUserInfoResponse>(source);
                destination.User = DtoConverter.Convert(source.User);
                return destination;
            }
        }


        /// <summary>
        /// Build Processor
        /// </summary>
        public static void Build()
        {

            PipeLineOperationBuilder.BuildBasicProcessor<GetUserInfoReq, GetUserInfoRes, GetUserInfoReq, GetUserInfoRes>()

                 .CoreOperation<GetUserInfoBizOp>()
                 .Build();


            PipeLineOperationBuilder.BuildBasicProcessor<GetUserInfoRequest, GetUserInfoResponse, GetUserInfoReq, GetUserInfoRes>()
           //.FrontEndValiadtor<Validator>()
           .FrontEndValiadtor<AuthorizeValidator>()
           .InboundConverter<Converter>()
           .CoreOperation<GetUserInfoBizOp>()
           .OutboundConverter<Converter>()
           .DefaultReponseGenerator<DefaultMessage<GetUserInfoResponse>>()
           .Build();

        }

    }
}
