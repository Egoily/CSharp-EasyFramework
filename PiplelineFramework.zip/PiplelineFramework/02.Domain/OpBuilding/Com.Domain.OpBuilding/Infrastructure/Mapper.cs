﻿using Com.Domain.OpBuilding.Mapping;
using Com.Domain.Operation.Mapping;

namespace Com.Domain.OpBuilding.Infrastructure
{
    public class Mapper
    {
        public static void AutoMapperConfigure()
        {
            AutoMapper.Mapper.Initialize(cfg =>
            {
                cfg.AddProfile<ContractProfile>();
                cfg.AddProfile<DtoMappingProfile>();

            });
        }
    }
}