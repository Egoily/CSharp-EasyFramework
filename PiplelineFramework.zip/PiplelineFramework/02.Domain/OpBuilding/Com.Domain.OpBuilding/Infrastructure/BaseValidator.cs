﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Com.Domain.Operation.Impl;
using Com.Framework.Contract;
using Com.Framework.Model.Exceptions;
using Com.Framework.Model.Operation.Messages;

namespace Com.Domain.OpBuilding.Infrastructure
{
    /// <summary>
    /// The Base Validator
    /// </summary>
    public class BaseValidator<T> : IValidator<T> where T : BaseRequest, new()
    {
        public virtual bool Validate(T request, List<string> messages)
        {
            if (messages != null && messages.Any())
                throw new DataValidationErrorException(string.Join(Environment.NewLine, messages), ErrorCodes.InvalidRequest);

            return true;
        }

        public virtual bool Authorize(Credential credential,string message)
        {
            if(!string.IsNullOrEmpty(message))
                throw new AuthorizationErrorException( message, ErrorCodes.Unauthorized);
            return true;
        }
    }
}