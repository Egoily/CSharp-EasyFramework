﻿using Com.Domain.OpBuilding.Builder;

namespace Com.Domain.OpBuilding.Infrastructure
{
    /// <summary>
    /// 
    /// </summary>
    public class Initializer
    {
        public static bool IsInitialized = false;
        public static void Initialize()
        {
            if (IsInitialized)
                return;
            InitializeMappings();
            InitializePipeline();
           IsInitialized = true;
        }


        private static void InitializeMappings()
        {
            //AutoMapper cnfiguration
            Mapper.AutoMapperConfigure();
        }

        private static void InitializePipeline()
        {
            PipelineBuilder.BuildProcessors();
        }


    }
}