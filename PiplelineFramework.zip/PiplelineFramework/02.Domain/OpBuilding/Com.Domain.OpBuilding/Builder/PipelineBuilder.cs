﻿using Com.Domain.OpBuilding.Processors;

namespace Com.Domain.OpBuilding.Builder
{
    public class PipelineBuilder
    {
        /// <summary>
        /// Build Pipeline
        /// </summary>
        public static void BuildProcessors()
        {
            GetUserInfoProcessor.Build();
        }

    }
}
