﻿using System;
using System.Runtime.Serialization;
using Com.Framework.Model.Operation.Messages;

namespace Com.Domain.OpBuilding.Contract.DtoModel
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract(Namespace = Declarations.NameSpace)]
    [Serializable]
    public class UserInfo
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string UserId { get; set; }

        /// <summary>
        ///
        /// </summary>
        [DataMember]
        public string UserName { get; set; }

    }
}
