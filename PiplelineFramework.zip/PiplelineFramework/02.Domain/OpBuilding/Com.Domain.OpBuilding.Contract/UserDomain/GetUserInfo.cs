﻿using Com.Framework.Model.Operation.Messages;
using System;
using System.Runtime.Serialization;
using Com.Domain.OpBuilding.Contract.DtoModel;

namespace Com.Domain.OpBuilding.Contract.UserDomain
{

    /// <summary>
    ///
    /// </summary>
    [DataContract(Namespace = Declarations.NameSpace)]
    [Serializable]
    public class GetUserInfoRequest : BaseRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string UserId { get; set; }

    }

    /// <summary>
    ///
    /// </summary>
    [DataContract(Namespace = Declarations.NameSpace)]
    [Serializable]
    public class GetUserInfoResponse : BaseResponse
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public UserInfo User { get; set; }
    }

}
