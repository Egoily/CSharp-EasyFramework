﻿using Com.Application.Services;
using Com.Domain.OpBuilding.Contract.UserDomain;
using Com.Domain.Operation.Contract.UserDomain;
using log4net.Config;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Com.Application.Services.UnitTests
{
    [TestClass()]
    public class ServiceProviderUnitTests
    {
        [TestInitialize()]
        public void Initialize()
        {
            //Initialize Log4net
            XmlConfigurator.Configure();
        }

        [TestMethod()]
        public void GetUserInfo_ReturnOK()
        {
            //TODO:
            var provider = new ServiceProvider();
            var request = new GetUserInfoReq()
            {
                UserId = "1"
            };
            var response = provider.GetUserInfo(request);
        }

        [TestMethod()]
        public void GetUserInfo2_ReturnOK()
        {
            //TODO:
            var provider = new ServiceProvider();
            var request = new GetUserInfoRequest()
            {
                UserId = "1"
            };
            var response = provider.GetUserInfo2(request);
        }

        [TestMethod()]
        public void GetUserInfo2_ReturnNotOK()
        {
            //TODO:
            var provider = new ServiceProvider();
            var request = new GetUserInfoRequest()
            {
                UserId = ""
            };
            var response = provider.GetUserInfo2(request);
        }

        [TestMethod()]
        public void GetUserInfo3_ReturnOK()
        {
            //TODO:
            var provider = new ServiceProvider();
            var request = new GetUserInfoRequest()
            {
                UserId = "2"
            };
            var response = provider.GetUserInfo3(request);
        }
    }
}