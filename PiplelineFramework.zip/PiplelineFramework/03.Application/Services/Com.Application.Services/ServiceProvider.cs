﻿using System.Reflection;
using Com.Domain.OpBuilding.Contract.UserDomain;
using Com.Domain.OpBuilding.Infrastructure;
using Com.Framework.Infrastructure;
using Com.Framework.Model.Operation.Messages;
using Com.Domain.Operation.Contract.UserDomain;

namespace Com.Application.Services
{
    public class ServiceProvider : IServiceProvider
    {
        #region  *fields
        private static readonly string Executor = "Application.Service";
        #endregion

        public ServiceProvider()
        {
            Initializer.Initialize();
        }

        /// <summary>
        /// 初始化
        /// </summary>
        public static void Initialize()
        {
            Initializer.Initialize();

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public GetUserInfoRes GetUserInfo(GetUserInfoReq request)
        {
            Invokation invokation = new Invokation()
            {
                Executor = Executor,
                Invoker = MethodBase.GetCurrentMethod(),
            };
            return (BussinessOperationProcessor.ProcessRequest<GetUserInfoReq, GetUserInfoRes>(request, invokation));
        }

        public GetUserInfoResponse GetUserInfo2(GetUserInfoRequest request)
        {
            Invokation invokation = new Invokation()
            {
                Executor = Executor,
                Invoker = MethodBase.GetCurrentMethod(),
            };
            return (BussinessOperationProcessor.ProcessRequest<GetUserInfoRequest, GetUserInfoResponse>(request, invokation));
        }
        public GetUserInfoResponse GetUserInfo3(GetUserInfoRequest request)
        {
            Invokation invokation = new Invokation()
            {
                Executor = Executor,
                Invoker = MethodBase.GetCurrentMethod(),
                Credential = new Credential() { UserName = "Ego", Password = "1234" }
            };
            return (BussinessOperationProcessor.ProcessRequest<GetUserInfoRequest, GetUserInfoResponse>(request, invokation));
        }

    }
}
