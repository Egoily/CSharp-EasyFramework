﻿using Com.Domain.OpBuilding.Contract.UserDomain;
using Com.Domain.Operation.Contract.UserDomain;

namespace Com.Application.Services
{
    public interface IServiceProvider
    {
        GetUserInfoRes GetUserInfo(GetUserInfoReq request);

        GetUserInfoResponse GetUserInfo2(GetUserInfoRequest request);
        GetUserInfoResponse GetUserInfo3(GetUserInfoRequest request);
    }
}
