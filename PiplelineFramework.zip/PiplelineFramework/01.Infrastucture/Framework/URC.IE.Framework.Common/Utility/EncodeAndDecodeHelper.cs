﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace URC.IE.Framework.Common.Utility
{
    public sealed class EncodeAndDecodeHelper
    {

        private static string DesKey = string.Empty;

        public static string DecodeConnectionString(string ConnectionValue, string DesKey)
        {
            foreach (var item in ConnectionValue.Split(';'))
            {
                if (item.StartsWith("PWD=") || item.StartsWith("UID="))
                {
                    ConnectionValue = ConnectionValue.Replace(item.Substring(4), EncodeAndDecodeHelper.DecryptStr(item.Substring(4), DesKey));
                }
            }
            return ConnectionValue;
        }

        public static string EncryptStr(string str, string DESKey)
        {
            try
            {
                return EncodeAndDecodeHelper.EncryptDES(str, DESKey);
            }
            catch (Exception)
            {
                return str;
            }
        }

        public static string DecryptStr(string str, string DESKey)
        {
            try
            {
                return EncodeAndDecodeHelper.DecryptDES(str, DESKey);
            }
            catch (Exception)
            {
                return str;
            }
        }

        /// <summary>
        /// Base64位编码加密
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string Base64Encrypt(string str)
        {
            byte[] encbuff = System.Text.Encoding.UTF8.GetBytes(str);
            return Convert.ToBase64String(encbuff);
        }

        /// <summary>
        /// Base64位编码解密
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string Base64Decrypt(string str)
        {
            byte[] decbuff = Convert.FromBase64String(str);
            return System.Text.Encoding.UTF8.GetString(decbuff);
        }

        /// <summary>
        /// 随机生成KEY
        /// </summary>
        /// <returns></returns>
        public static string GenerateKey()
        {
            int _len = 8;
            Random random = new Random(DateTime.Now.Millisecond);
            byte[] keybyte = new byte[_len];
            for (int i = 0; i < _len; i++)
            {
                keybyte[i] = (byte)random.Next(65, 122);
            }
            return ASCIIEncoding.ASCII.GetString(keybyte);
        }

        /// <summary>
        /// DES 加密过程
        /// </summary>
        /// <param name="dataToEncrypt">待加密数据</param>
        /// <param name="DESKey"></param>
        /// <returns></returns>
        private static string EncryptDES(string dataToEncrypt, string DESKey)
        {
            if (string.IsNullOrEmpty(dataToEncrypt) || string.IsNullOrEmpty(DESKey))
            {
                return string.Empty;
            }
            try
            {
                using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
                {
                    byte[] inputByteArray = Encoding.Default.GetBytes(dataToEncrypt);//把字符串放到byte数组中
                    des.Key = ASCIIEncoding.ASCII.GetBytes(DESKey); //建立加密对象的密钥和偏移量
                    des.IV = ASCIIEncoding.ASCII.GetBytes(DESKey);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(inputByteArray, 0, inputByteArray.Length);
                            cs.FlushFinalBlock();
                            StringBuilder ret = new StringBuilder();
                            foreach (byte b in ms.ToArray())
                            {
                                ret.AppendFormat("{0:x2}", b);
                            }
                            return ret.ToString();
                        }
                    }
                }
            }
            catch (Exception)
            {
                return dataToEncrypt;
            }
        }

        /// <summary>
        /// DES 解密过程
        /// </summary>
        /// <param name="dataToDecrypt">待解密数据</param>
        /// <param name="DESKey"></param>
        /// <returns></returns>
        private static string DecryptDES(string dataToDecrypt, string DESKey)
        {
            if (string.IsNullOrEmpty(dataToDecrypt) || string.IsNullOrEmpty(DESKey))
            {
                return string.Empty;
            }
            try
            {
                using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
                {
                    byte[] inputByteArray = new byte[dataToDecrypt.Length / 2];
                    for (int x = 0; x < dataToDecrypt.Length / 2; x++)
                    {
                        int i = (Convert.ToInt32(dataToDecrypt.Substring(x * 2, 2), 16));
                        inputByteArray[x] = (byte)i;
                    }
                    des.Key = ASCIIEncoding.ASCII.GetBytes(DESKey); //建立加密对象的密钥和偏移量，此值重要，不能修改
                    des.IV = ASCIIEncoding.ASCII.GetBytes(DESKey);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(inputByteArray, 0, inputByteArray.Length);
                            cs.FlushFinalBlock();
                            return System.Text.Encoding.Default.GetString(ms.ToArray());
                        }
                    }
                }
            }
            catch (Exception)
            {
                return dataToDecrypt;
            }
        }

        public static string StrToAsc(string strSource)
        {
            byte[] array = System.Text.Encoding.ASCII.GetBytes(strSource);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < array.Length; i++)
            {
                int asciicode = (int)(array[i]);
                sb.Append(asciicode.ToString().PadLeft(3, '0'));
            }
            return sb.ToString();
        }

        public static string AscToStr(string strSource)
        {
            byte[] buff = new byte[strSource.Length / 3];
            int index = 0;
            for (int i = 0; i < strSource.Length; i += 3)
            {
                buff[index] = (byte)int.Parse(strSource.Substring(i, 3));
                ++index;
            }
            string result = new System.Text.ASCIIEncoding().GetString(buff);
            return result;
        }

        #region DES加密字符串

        /// <summary>
        /// DES加密字符串
        /// </summary>
        /// <param name="encryptString">待加密的字符串</param>
        /// <param name="encryptKey">加密密钥,要求为8位</param>
        /// <returns>加密成功返回加密后的字符串，失败返回源串</returns>
        public static string EncryptDESForBackGroundOrder(string encryptString, string key)
        {
            try
            {
                byte[] rgbKey = Encoding.UTF8.GetBytes(key);
                byte[] rgbIV = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };
                byte[] inputByteArray = Encoding.UTF8.GetBytes(encryptString);
                DESCryptoServiceProvider dCSP = new DESCryptoServiceProvider();
                MemoryStream mStream = new MemoryStream();
                CryptoStream cStream = new CryptoStream(mStream, dCSP.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                cStream.Write(inputByteArray, 0, inputByteArray.Length);
                cStream.FlushFinalBlock();
                return Convert.ToBase64String(mStream.ToArray());
            }
            catch
            {
                return encryptString;
            }
        }

        #endregion DES加密字符串
    }
}