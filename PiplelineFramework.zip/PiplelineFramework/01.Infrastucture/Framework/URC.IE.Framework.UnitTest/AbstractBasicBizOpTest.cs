﻿using Com.Framework.Model.Operation.Messages;
using Com.Framework.Operation;

namespace Com.Framework.UnitTest
{
    /// <summary>
    /// Used to create nunit BizOp
    /// </summary>
    /// <typeparam name="TBizOp"></typeparam>
    /// <typeparam name="TDtoInput"></typeparam>
    /// <typeparam name="TDtoOutput"></typeparam>
    /// <typeparam name="TCoreInput"></typeparam>
    /// <typeparam name="TCoreOutput"></typeparam>
    public abstract class AbstractBasicBizOpTest<TBizOp, TDtoInput, TDtoOutput, TCoreInput, TCoreOutput>
        where TBizOp : AbstractBasicBizOp<TDtoInput, TDtoOutput, TCoreInput, TCoreOutput>, new()
        where TDtoInput : BaseRequest, new()
        where TDtoOutput : BaseResponse, new()
        where TCoreInput : BaseRequest, new()
        where TCoreOutput : BaseResponse, new()
    {
        /// <summary>
        /// Fake invoker to set in the BizOp.ProcessFromCustomerModel input parameter
        /// </summary>
        protected readonly Invokation FakeInvoker = URC.IE.Framework.UnitTest.Utilities.FakeInvoker.FakeInvokationEnvironment();

        /// <summary>
        /// Call the BizOp
        /// </summary>
        /// <param name="request"></param>
        /// <returns>BizOp response</returns>
        public virtual TDtoOutput CallBizOp(TDtoInput request)
        {
            var response = new TDtoOutput();

            TBizOp bizop = new TBizOp();

            response = bizop.Process(request,
                new NullValidator<TDtoInput>(), new SameTypeConverter<TDtoInput>(), new SameTypeConverter<TDtoOutput>(), FakeInvoker);

            return response;
        }
    }
}