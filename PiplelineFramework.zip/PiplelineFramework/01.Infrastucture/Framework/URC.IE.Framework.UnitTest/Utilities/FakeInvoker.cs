﻿using Com.Framework;
using Com.Framework.Model.Operation.Messages;
using URC.IE.Framework;

namespace URC.IE.Framework.UnitTest.Utilities
{
    /// <summary>
    /// Fakeinvoker to trace in Bizop
    /// </summary>
    public static class FakeInvoker
    {
        /// <summary>
        /// Set up enviroment
        /// </summary>
        /// <returns></returns>
        public static Invokation FakeInvokationEnvironment()
        {
            return new Invokation()
            {
                DestinationIp = "127.0.0.1",
                Invoker = null,
                ProxyIp = "127.0.0.1",
                ServingUrl = "dummyURL",
                SourceIp = "127.0.0.1",
            };
        }
    }
}