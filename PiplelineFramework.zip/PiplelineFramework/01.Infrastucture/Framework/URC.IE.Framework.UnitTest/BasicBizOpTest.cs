﻿using Com.Framework.Model.Operation.Messages;
using Com.Framework.Operation;
using URC.IE.Framework.UnitTest;

namespace Com.Framework.UnitTest
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TBizOp"></typeparam>
    /// <typeparam name="TDtoInput"></typeparam>
    /// <typeparam name="TDtoOutput"></typeparam>
    /// <typeparam name="TCoreInput"></typeparam>
    /// <typeparam name="TCoreOutput"></typeparam>
    public class BasicBizOpTest<TBizOp, TDtoInput, TDtoOutput, TCoreInput, TCoreOutput> : AbstractBasicBizOpTest<TBizOp, TDtoInput, TDtoOutput, TCoreInput, TCoreOutput>
        where TBizOp : AbstractBasicBizOp<TDtoInput, TDtoOutput, TCoreInput, TCoreOutput>, new()
        where TDtoInput : BaseRequest, new()
        where TDtoOutput : BaseResponse, new()
        where TCoreInput : BaseRequest, new()
        where TCoreOutput : BaseResponse, new()
    {
    }
}