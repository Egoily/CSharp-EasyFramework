﻿using System;
using System.Linq;
using System.Reflection;
using Com.Framework.Model;
using Newtonsoft.Json;

namespace Com.Framework.Util
{
    /// <summary>
    /// 
    /// </summary>
    public class SecurityConverter : JsonConverter
    {
        /// <summary>
        /// 
        /// </summary>
        public override bool CanRead
        {
            get { return false; }
        }
        /// <summary>
        /// 是否允许转换JSON字符串时调用
        /// </summary>
        public override bool CanWrite
        {
            get { return true; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objectType"></param>
        /// <returns></returns>
        public override bool CanConvert(Type objectType)
        {
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="objectType"></param>
        /// <param name="existingValue"></param>
        /// <param name="serializer"></param>
        /// <returns></returns>
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            return existingValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="writer"></param>
        /// <param name="value"></param>
        /// <param name="serializer"></param>
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
          

            foreach (PropertyInfo pi in value.GetType().GetProperties())
            {
                writer.WritePropertyName(pi.Name);
                if (pi.GetCustomAttributes(typeof(SecurityFieldAttibute), true).Any())
                {
                    writer.WriteValue("****");
                }
                else
                {
                    writer.WriteValue(pi.GetValue(value));
                }
            }
           
        }
    }

}
