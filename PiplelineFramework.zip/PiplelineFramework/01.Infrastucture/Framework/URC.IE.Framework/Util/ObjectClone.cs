﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Com.Framework.Model;

namespace Com.Framework.Util
{
    /// <summary>
    /// 
    /// </summary>
    public static class ObjectClone
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static object SecurityClone(this object obj)
        {
            Object targetDeepCopyObj;
            Type targetType = obj.GetType();
            //值类型  
            if (targetType.IsValueType == true)
            {
                targetDeepCopyObj = obj;
            }
            //引用类型   
            else
            {
                targetDeepCopyObj = System.Activator.CreateInstance(targetType);   //创建引用对象   
                System.Reflection.MemberInfo[] memberCollection = obj.GetType().GetMembers();

                foreach (System.Reflection.MemberInfo member in memberCollection)
                {
                    if (member.MemberType == System.Reflection.MemberTypes.Field)
                    {
                        System.Reflection.FieldInfo field = (System.Reflection.FieldInfo)member;
                        Object fieldValue = field.GetValue(obj);
                        if (fieldValue is ICloneable)
                        {
                            field.SetValue(targetDeepCopyObj, (fieldValue as ICloneable).Clone());
                        }
                        else
                        {
                            field.SetValue(targetDeepCopyObj, SecurityClone(fieldValue));
                        }

                    }
                    else if (member.MemberType == System.Reflection.MemberTypes.Property)
                    {
                        System.Reflection.PropertyInfo pi = (System.Reflection.PropertyInfo)member;
                        MethodInfo info = pi.GetSetMethod(false);
                        if (info != null)
                        {
                            object propertyValue = pi.GetValue(obj, null);

                            if (pi.PropertyType.IsGenericType || pi.PropertyType.IsArray)
                            {
                                pi.SetValue(targetDeepCopyObj, propertyValue == null ? null : Clone(propertyValue), null);
                            }
                            else {

                                if (propertyValue is ICloneable)
                                {
                                    if (pi.GetCustomAttributes(typeof(SecurityFieldAttibute), true).Any())
                                    {
                                        pi.SetValue(targetDeepCopyObj, "****", null);
                                    }
                                    else
                                    {
                                        pi.SetValue(targetDeepCopyObj, propertyValue == null ? null : (propertyValue as ICloneable).Clone(), null);
                                    }

                                }
                                else
                                {
                                    if (pi.GetCustomAttributes(typeof(SecurityFieldAttibute), true).Any())
                                    {
                                        pi.SetValue(targetDeepCopyObj, "****", null);
                                    }
                                    else
                                    {
                                        pi.SetValue(targetDeepCopyObj, propertyValue == null ? null : SecurityClone(propertyValue), null);
                                    }

                                }
                            }
                        }

                    }
                }
            }
            return targetDeepCopyObj;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static T Clone<T>(T obj)
        {
            using (Stream objectStream = new MemoryStream())
            {
                //利用 System.Runtime.Serialization序列化与反序列化完成引用对象的复制  
                IFormatter formatter = new BinaryFormatter();
                formatter.Serialize(objectStream, obj);
                objectStream.Seek(0, SeekOrigin.Begin);
                return (T)formatter.Deserialize(objectStream);
            }
        }
    }
}
