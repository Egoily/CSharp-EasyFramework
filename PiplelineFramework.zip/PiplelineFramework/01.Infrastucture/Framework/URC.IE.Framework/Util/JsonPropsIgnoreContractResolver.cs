﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Com.Framework.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Com.Framework.Util
{
    /// <summary>
    /// 
    /// </summary>
    public class JsonPropsIgnoreContractResolver : DefaultContractResolver
    {

        /// <summary>
        /// 
        /// </summary>
        public JsonPropsIgnoreContractResolver()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="memberSerialization"></param>
        /// <returns></returns>
        protected override IList<JsonProperty> CreateProperties(Type type, MemberSerialization memberSerialization)
        {
            var ignoreNames = new List<string>();
            foreach (PropertyInfo pi in type.GetProperties())
            {
                if (pi.GetCustomAttributes(typeof(JsonPropIgnoreAttibute), true).Any())
                {
                    ignoreNames.Add(pi.Name);
                }
            }

            IList<JsonProperty> list = base.CreateProperties(type, memberSerialization);
            return list.Where(p =>
            {
                return !ignoreNames.Contains(p.PropertyName);
            }).ToList();
        }
    }
}
