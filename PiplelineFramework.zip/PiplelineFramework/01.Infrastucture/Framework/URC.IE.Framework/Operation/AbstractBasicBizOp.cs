﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Com.Framework.Contract;
using Com.Framework.Infrastructure;
using Com.Framework.Model.Enumeration;
using Com.Framework.Model.Exceptions;
using Com.Framework.Model.Operation;
using Com.Framework.Model.Operation.Messages;
using log4net;
using Newtonsoft.Json;

namespace Com.Framework.Operation
{
    /// <summary>
    /// Class that provides the commong functionality for any operation, as Authentication,
    /// Authorization.It forces the implementation of the business logic.
    /// </summary>
    /// <typeparam name="TDtoInput">The external type of the request in DTO style</typeparam>
    /// <typeparam name="TDtoOutput">The external type of the response in DTO style</typeparam>
    /// <typeparam name="TCoreInput">The internal type of the request using the domain model</typeparam>
    /// <typeparam name="TCoreOutput">The internal type of the response using the domain model</typeparam>
    public abstract class AbstractBasicBizOp<TDtoInput, TDtoOutput, TCoreInput, TCoreOutput>
        : BusinessOperation, IBasicBizOp<TDtoInput, TDtoOutput, TCoreInput, TCoreOutput>
        where TDtoInput : BaseRequest, new()
        where TDtoOutput : BaseResponse, new()
        where TCoreInput : BaseRequest, new()
        where TCoreOutput : BaseResponse, new()
    {
        // StaticFieldInGenericType
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);


        /// <summary>
        /// The time if any of the operation start at DTO time.
        /// </summary>
        private static DateTime? DtoOperationStartTime { get; set; }

        /// <summary>
        /// Operating Time
        /// </summary>
        [ThreadStatic]
        public static DateTime OperatingTime = DateTime.Now;

        /// <summary>
        /// This method operates in model. Converts the DTORequest to the Request types
        /// </summary>
        /// <param name="dtoInput">The request in DTO form</param>
        /// <param name="coreInput">The request in Internal form, prefilled with the common parameters</param>
        /// <returns>the operation in the et Internal form</returns>
        protected abstract void Inbound(TDtoInput dtoInput, ref TCoreInput coreInput);

        /// <summary>
        /// Method implemented by the inheriting class that actually performs the core operation
        /// </summary>
        /// <param name="request">Input parameter for the request</param>
        /// <param name="invokation">The information about the invokation of the operation</param>
        /// <returns>The response of processing the request</returns>
        protected abstract TCoreOutput ProcessBusinessLogic(TCoreInput request, Invokation invokation);

        /// <summary>
        /// Coverts the response/result of the process (in internal form) to the DTO form.
        /// </summary>
        /// <param name="coreOutput">the result of process implementation</param>
        /// <param name="dtoOutput">the preallocated response, will all auto fields mapped</param>
        /// <returns>the response in the DTO form</returns>
        protected abstract void Outbound(TCoreOutput coreOutput, ref TDtoOutput dtoOutput);


        /// <summary>
        /// trace operation
        /// </summary>
        /// <param name="trace"></param>
        /// <returns></returns>
        protected override bool TraceOperation(object trace)
        {
            return true;
        }

        /// <summary>
        /// Process a request in  domain model, to invoke internally, not in DTO form
        /// </summary>
        /// <param name="request">the request to be processed</param>
        /// <param name="invoker">the invokation environment for the request</param>
        /// <returns>The result of the processing</returns>
        public TCoreOutput Process(TCoreInput request, Invokation invoker)
        {
            OperatingTime = DateTime.Now;
            Log.InfoFormat("==========>>Begin business logic:{0} ==========", invoker.Invoker.Name);
            //Invoke the operation
            TCoreOutput response = ProcessBusinessLogic(request, invoker);
            Log.InfoFormat("<<==========End business logic:{0} ==========", invoker.Invoker.Name);
            return response;
        }

        /// <summary>
        /// Implementation of process, takes care of the main infrastructure logic as
        /// ExceptionHandling, operation log Creation and transactions.
        /// </summary>
        /// <typeparam name="TRequest">The type of the request in the customer model</typeparam>
        /// <typeparam name="TResponse">The type of the response in the customer model</typeparam>
        /// <param name="request">the reques in Customer DTO form (TDTOExternalIn) </param>
        /// <param name="validator">The validator</param>
        /// <param name="inboundConverter">the converter for the the DTO request in customer form to the DTO request in  Form</param>
        /// <param name="outboundConverter">the converter for the the DTO response in form to the DTO response in customer</param>
        /// <param name="invokation">the request invockation environmnt.</param>
        /// <returns>the response in the DTO customer form</returns>
        public TResponse Process<TRequest, TResponse>(TRequest request, IValidator<TRequest> validator, ITypeConverter<TRequest, TDtoInput> inboundConverter, ITypeConverter<TDtoOutput, TResponse> outboundConverter, Invokation invokation)
            where TRequest : BaseRequest, new()
            where TResponse : BaseResponse, new()

        {
            DtoOperationStartTime = DateTime.Now;

            try
            {
                //Request validation
                validator.Authorize(invokation.Credential,string.Empty);

                if (Log.IsDebugEnabled)
                {
                    Log.DebugFormat(" Accept Request {0}:{1}", typeof(TRequest), JsonConvert.SerializeObject(request, Formatting.None));
                }

                //Request validation
                validator.Validate(request, new List<string>());

                //Convert to the dtoInput from the request
                var dtoInput = inboundConverter.Convert(request);
                if (Log.IsDebugEnabled)
                {
                    Log.DebugFormat(" Convert to dtoInput {0}:{1}", typeof(TDtoInput),
                        JsonConvert.SerializeObject(dtoInput));
                }



                //Inbound to Core from Dto
                var coreInput = AutoMapInboundFields(dtoInput);
                if (Log.IsDebugEnabled)
                {
                    Log.DebugFormat(" Convert to coreInput {0}:{1}", typeof(TCoreInput),
                        JsonConvert.SerializeObject(coreInput));
                }

                //Process logic
                var coreOutput = Process(coreInput, invokation);

                if (Log.IsDebugEnabled)
                {
                    Log.DebugFormat("Return coreOutput {0}:{1}", typeof(TCoreOutput),
                        JsonConvert.SerializeObject(coreOutput));
                }
                //Outbound to Dto from Core
                var dtoOutput = AutoMapOutboundFields(coreOutput);
                if (Log.IsDebugEnabled)
                {
                    Log.DebugFormat(" Convert to dtoOutput {0}:{1}", typeof(TDtoInput),
                        JsonConvert.SerializeObject(dtoOutput));
                }
                //Convert to the dtoOutput from the coreOutput
                var response = outboundConverter.Convert(dtoOutput);
                if (Log.IsDebugEnabled)
                {
                    Log.DebugFormat(" Convert to customer response model {0}:{1}", typeof(TDtoInput), JsonConvert.SerializeObject(response, Formatting.None));
                }

                //Return here.
                return (response);

            }
            //We need to ensure that the trace is kept, but only in case of exception.
            catch (Exception ex)
            {
                throw ex;

            }

        }

        private TCoreInput AutoMapInboundFields(TDtoInput dtoInput)
        {
            TCoreInput coreInput = new TCoreInput
            {
            };
            if (typeof(TDtoInput) == typeof(TCoreInput))
            {
                coreInput = dtoInput as TCoreInput;
            }
            Inbound(dtoInput, ref coreInput);
            return (coreInput);
        }

        private TDtoOutput AutoMapOutboundFields(TCoreOutput coreOutput)
        {
            TDtoOutput dtoOutput = new TDtoOutput
            {
                Code = coreOutput.Code,
                Message = coreOutput.Message,
                ResultType = coreOutput.ResultType,
            };
            if (typeof(TCoreOutput) == typeof(TDtoOutput))
            {
                dtoOutput = coreOutput as TDtoOutput;
            }
            Outbound(coreOutput, ref dtoOutput);

            return dtoOutput;
        }
    }
}