﻿using System.Collections.Generic;
using Com.Framework.Contract;
using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Operation
{
    /// <summary>
    /// Implementation of validator that does not perform any validation
    /// </summary>
    /// <typeparam name="T">THe type of object</typeparam>
    public class NullValidator<T> : IValidator<T>
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objectToValidate"></param>
        /// <param name="messages"></param>
        /// <returns></returns>
        public bool Validate(T objectToValidate, List<string> messages)
        {
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="credential"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool Authorize(Credential credential, string message)
        {
            return true;
        }
    }
}