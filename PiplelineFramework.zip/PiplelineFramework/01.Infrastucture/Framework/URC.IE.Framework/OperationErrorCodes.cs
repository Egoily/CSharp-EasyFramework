﻿using System;

namespace Com.Framework
{
    /// <summary>
    /// Enumeration of all possible errors throw by the framework.
    /// </summary>
    public class OperationErrorCodes
    {
        /// <summary>
        /// THe start number for all the errors produced by the operation framework
        /// </summary>
        public const Int32 ErrorBase = 9000;
        /// <summary>
        /// Unauthorized
        /// </summary>
        public const Int32 Unauthorized = ErrorBase + 1;
        /// <summary>
        ///
        /// </summary>
        public const Int32 NullRequest = ErrorBase + 2;

    }
}