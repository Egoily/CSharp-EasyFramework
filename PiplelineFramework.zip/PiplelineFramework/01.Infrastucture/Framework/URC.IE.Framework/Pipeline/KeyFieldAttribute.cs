﻿using System;

namespace Com.Framework.Pipeline
{
    /// <summary>
    /// The atrribute to mark a request field with the key field
    /// </summary>
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = true, Inherited = false)]
    public class KeyFieldAttribute : Attribute
    {

    }
}