﻿using System.Reflection;
using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Pipeline
{
    /// <summary>
    /// Interface/Contract for any front end operation (Customer contract)
    /// </summary>
    /// <typeparam name="TInput">The type of the input parameter of the operation</typeparam>
    /// <typeparam name="TOutput">The type of the output of the operation</typeparam>
    public interface IFrontEndProcessor<in TInput, out TOutput>
        where TInput : class
        where TOutput : class
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <param name="invokation"></param>
        /// <returns></returns>
        TOutput ProcessRequest(TInput request, Invokation invokation);


    }
}