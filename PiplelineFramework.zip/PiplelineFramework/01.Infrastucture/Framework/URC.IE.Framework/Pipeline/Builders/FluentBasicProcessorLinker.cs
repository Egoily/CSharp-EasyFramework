﻿using System;
using Com.Framework.Contract;
using Com.Framework.Infrastructure;
using Com.Framework.Model.Exceptions;
using Com.Framework.Model.Operation.Messages;
using Com.Framework.Operation;
using Com.Framework.Pipeline.Processors;

namespace Com.Framework.Pipeline.Builders
{
    /// <summary>
    /// Helper class to link front end messages to the core implementation fluently
    /// </summary>
    /// <typeparam name="TRequest">The external type of the input message</typeparam>
    /// <typeparam name="TResponse">The external type of the output message</typeparam>
    /// <typeparam name="TDtoInput">The core type of the operation</typeparam>
    /// <typeparam name="TDtoOutput">The core type of the operation</typeparam>
    public class FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput>
        where TRequest : BaseRequest, new()
        where TResponse : BaseResponse, new()
        where TDtoInput : BaseRequest, new()
        where TDtoOutput : BaseResponse, new()
    {
        private Type _inputValidator;
        private Type _inboundConverter;
        private Type _processor;
        private Type _outBoundConverter;
        private Type _defaultMessageGenerator;

        /// <summary>
        /// Sets the validator for the Front end message, TValidator mus implement <![CDATA[IValidator<TRequest>]]>
        /// </summary>
        /// <typeparam name="TValidator">The type to be used as validator</typeparam>
        /// <returns>The fluent validator</returns>
        public FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput> FrontEndValiadtor<TValidator>()
            where TValidator : IValidator<TRequest>
        {
            _inputValidator = typeof(TValidator);
            return this;
        }


        /// <summary>
        /// This method will set a <![CDATA[NullValidator<TRequest>]]> as validator that does not perform any validation
        /// </summary>
        /// <returns></returns>
        public FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput> NoFrontEndValidator()
        {
            _inputValidator = typeof(NullValidator<TRequest>);
            return this;
        }

        /// <summary>
        /// The converter used to transform TRequest to TDtoInput must implement <![CDATA[ITypeConverter<TRequest, TDtoInput>]]>
        /// </summary>
        /// <typeparam name="TConverter">The type that implements  <![CDATA[ITypeConverter<TRequest, TDtoInput>]]></typeparam>
        /// <returns>The fluent validator</returns>
        public FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput> InboundConverter<TConverter>()
            where TConverter : ITypeConverter<TRequest, TDtoInput>
        {
            _inboundConverter = typeof(TConverter);
            return this;
        }

        /// <summary>
        /// Sets the type that will be used to process the request, the type must implement <![CDATA[IBusinessOperation<TDtoInput,TDtoOutput>]]>
        /// </summary>
        /// <typeparam name="TOperationProcessor">The type that implements IBusinessOperation TDtoInput, TDtoOutput </typeparam>
        /// <returns>The fluent validator</returns>
        public FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput> CoreOperation<TOperationProcessor>()
            where TOperationProcessor : IBasicProcess<TDtoInput, TDtoOutput>
        {
            _processor = typeof(TOperationProcessor);
            return this;
        }


        /// <summary>
        ///  The converter used to transform TDtoOutput to TResponse must <![CDATA[ITypeConverter<TDtoOutput, TResponse>]]>
        /// </summary>
        /// <typeparam name="TConverter"></typeparam>
        /// <returns></returns>
        public FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput> OutboundConverter<TConverter>()
            where TConverter : ITypeConverter<TDtoOutput, TResponse>
        {
            _outBoundConverter = typeof(TConverter);
            return (this);
        }

        /// <summary>
        /// Sets a type used to generate the default responses, in case of unhandled Exception, must implement  <![CDATA[IDefaultResponseGenerator<TResponse>]]>
        /// </summary>
        /// <typeparam name="TGen">The type implementing  <![CDATA[IDefaultResponseGenerator<TResponse>]]></typeparam>
        /// <returns></returns>
        public FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput> DefaultReponseGenerator<TGen>()
            where TGen : IDefaultResponseGenerator<TResponse>
        {
            _defaultMessageGenerator = typeof(TGen);
            return this;
        }

        /// <summary>
        /// Sets true to use sessionId
        /// </summary>
        /// <returns></returns>
        public FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput> UseSessionAuthoritzation()
        {
            return this;
        }

        /// <summary>
        /// Registers the operation built in the pipeline, checking that contains all the elements required to process it
        /// </summary>
        public void Build()
        {

            if (_inputValidator == null)
            {
                _inputValidator = typeof(NullValidator<TRequest>);
            }
            if (_inboundConverter == null)
            {
                if (typeof(TRequest) != typeof(TDtoInput))
                {
                    throw new DevelopmentException("InboundConverter is not allowed null");
                
                }
                _inboundConverter = typeof(SameTypeConverter<TRequest>);

            }
            if (_outBoundConverter == null)
            {
                if (typeof(TDtoOutput) != typeof(TResponse))
                {
                    throw new DevelopmentException("OutBoundConverter is not allowed null");
                }
                _outBoundConverter = typeof(SameTypeConverter<TResponse>);
            }
            if (_defaultMessageGenerator == null)
            {
                _defaultMessageGenerator = typeof(DefaultMessage<TResponse>);
            }
            //Register the front end model validator
            PipeLineManager.RegisterValidator<TRequest>(_inputValidator);
            //Register the converter for DTO Front end model to front end model
            PipeLineManager.RegisterTypeConverter<TRequest, TDtoInput>(_inboundConverter);
            //Register the processor
            PipeLineManager.RegisterBasicProcessor<TDtoInput, TDtoOutput>(_processor);
            //Register type for the output direction
            PipeLineManager.RegisterTypeConverter<TDtoOutput, TResponse>(_outBoundConverter);
            //Register the default message generator
            PipeLineManager.RegisterDefaultResponseGenerator<TResponse>(_defaultMessageGenerator);



            PipeLineManager.RegisterFrontEndOperation<TRequest, TResponse>().To<BasicProcessor<TRequest, TResponse, TDtoInput, TDtoOutput>>();
        }
    }
}