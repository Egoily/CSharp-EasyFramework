﻿using Com.Framework.Contract;
using Ninject;

namespace Com.Framework.Pipeline.Builders
{
    /// <summary>
    /// Fluent builder part for the validator
    /// </summary>
    /// <typeparam name="TInput"></typeparam>
    public class ValidatorFluentBuilder<TInput> where TInput : class, new()
    {
        private readonly IKernel _kernel;

        /// <summary>
        /// Creates a new fluent configuration for validation
        /// </summary>
        /// <param name="kernel">the kernel to store the configured types</param>
        public ValidatorFluentBuilder(IKernel kernel)
        {
            _kernel = kernel;
        }

        /// <summary>
        /// Maps the Validator
        /// </summary>
        /// <typeparam name="TValidator">The type that must implement IValidator&lt;TInput&gt;</typeparam>
        public void To<TValidator>() where TValidator : IValidator<TInput>
        {
            _kernel.Bind<IValidator<TInput>>().To<TValidator>();
        }
    }
}