﻿using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Pipeline.Builders
{
    /// <summary>
    /// Helper class to start a fluent operation build
    /// </summary>
    public static class PipeLineOperationBuilder
    {

        /// <summary>
        /// Start a Fluent message configuration
        /// </summary>
        /// <typeparam name="TRequest">The DTO model for the input</typeparam>
        /// <typeparam name="TResponse">The DTO model for the output</typeparam>
        /// <typeparam name="TDtoInput">the domain model for the input</typeparam>
        /// <typeparam name="TDtoOutput">the domain model for the output</typeparam>
        /// <returns>the fluent builedr for the given types</returns>
        public static FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput> BuildBasicProcessor<TRequest, TResponse, TDtoInput, TDtoOutput>()
            where TRequest : BaseRequest, new()
            where TResponse : BaseResponse, new()
            where TDtoInput : BaseRequest, new()
            where TDtoOutput : BaseResponse, new()
        {
            return new FluentBasicProcessorLinker<TRequest, TResponse, TDtoInput, TDtoOutput>();
        }
   

    }
}