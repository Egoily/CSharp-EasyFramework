﻿using System;
using Com.Framework.Contract;
using Com.Framework.Model.Operation.Messages;
using Com.Framework.Pipeline.Builders;
using Ninject;

namespace Com.Framework.Pipeline
{
    /// <summary>
    /// Links customer front end model to business operations
    /// </summary>
    public static class PipeLineManager
    {
        private static readonly IKernel Kernel = new Ninject.StandardKernel();

        /// <summary>
        /// Method to get the internal implementation of an operation in DTO model
        /// </summary>
        /// <typeparam name="TDtoInput"></typeparam>
        /// <typeparam name="TDtoOutput"></typeparam>
        /// <returns>the IDTOBusinessOperation for the given types</returns>
        public static IBasicProcess<TDtoInput, TDtoOutput> GetBasicProcessor<TDtoInput, TDtoOutput>()
                   where TDtoInput : BaseRequest
                   where TDtoOutput : BaseResponse

        {
            return Kernel.TryGet<IBasicProcess<TDtoInput, TDtoOutput>>();
        }

        /// <summary>
        /// Gets the default message generator in case of unhandled error
        /// </summary>
        /// <typeparam name="TExternalOutput">The type of message that needs to be generated</typeparam>
        /// <returns>The default message generator for the type</returns>
        public static IDefaultResponseGenerator<TExternalOutput> GetDefaultMessageGenerator<TExternalOutput>()
        {
            return Kernel.TryGet<IDefaultResponseGenerator<TExternalOutput>>();
        }

        /// <summary>
        /// Gets the message processor for the Input and output types in Customer model
        /// </summary>
        /// <typeparam name="TInput">THe input type of the operation</typeparam>
        /// <typeparam name="TOutput">The output type of the operation</typeparam>
        /// <returns>The front end message processor for the given types</returns>
        public static IFrontEndProcessor<TInput, TOutput> GetPipeline<TInput, TOutput>()
            where TInput : class
            where TOutput : class
        {
            return Kernel.TryGet<IFrontEndProcessor<TInput, TOutput>>();
        }

        /// <summary>
        /// Gets a registered type converter for the Types provided
        /// </summary>
        /// <typeparam name="TSource">The source of the type to be converted</typeparam>
        /// <typeparam name="TDestination">The destination type of the conversion</typeparam>
        /// <returns>The ITypeConverter for TSource to TDestination</returns>
        public static ITypeConverter<TSource, TDestination> GetTypeConverter<TSource, TDestination>()
        {
            return Kernel.TryGet<ITypeConverter<TSource, TDestination>>();
        }
        /// <summary>
        /// Gets the IValidator for Tinput
        /// </summary>
        /// <typeparam name="TInput">the type to be validated</typeparam>
        /// <returns>the Ivalidator</returns>
        public static IValidator<TInput> GetValidator<TInput>()
        {
            return Kernel.TryGet<IValidator<TInput>>();
        }

        /// <summary>
        /// starts builing an operation with fluent configuration for the types
        /// </summary>
        /// <typeparam name="TInput">The input type of the Front end operation in customer model</typeparam>
        /// <typeparam name="TOutput">The output type of the Front end operation in customer model</typeparam>
        /// <returns>the fluent builder</returns>
        public static FrontEndFluentBuilder<TInput, TOutput> RegisterFrontEndOperation<TInput, TOutput>()
            where TInput : class, new()
            where TOutput : class, new()
        {
            return (new FrontEndFluentBuilder<TInput, TOutput>(Kernel));
        }
        /// <summary>
        /// Registers a validator with for the given type
        /// </summary>
        /// <typeparam name="TInput">The type to be validated</typeparam>
        /// <returns>the fluent validator builder for TInput</returns>
        public static ValidatorFluentBuilder<TInput> RegisterValidator<TInput>() where TInput : class, new()
        {
            return (new ValidatorFluentBuilder<TInput>(Kernel));
        }

        /// <summary>
        /// Registers a validator with for the given type
        /// </summary>
        /// <typeparam name="TInput">The type to be validated</typeparam>
        /// <param name="validator">the type of the validator, must implement Ivalidator for TInput</param>
        /// <returns>the fluent validator builder for TInput</returns>
        public static void RegisterValidator<TInput>(Type validator) where TInput : class, new()
        {
            if (validator == null || Kernel.TryGet<IValidator<TInput>>() != null) return;

            Kernel.Bind<IValidator<TInput>>().To(validator);


        }

        /// <summary>
        /// Registers a processor for DTO model, the type provided must implement
        /// IDTOBusinessOperation&lt;TCoreInput, TCoreOutput&gt;
        /// </summary>
        /// <typeparam name="TCoreInput">the DTO input type of the operation</typeparam>
        /// <typeparam name="TCoreOutput">the DTO output type of the operation</typeparam>
        /// <param name="processor">The actual type that implements the IDTOBusinessOperation</param>
        internal static void RegisterBasicProcessor<TCoreInput, TCoreOutput>(Type processor)
            where TCoreInput : BaseRequest, new()
            where TCoreOutput : BaseResponse, new()
        {
            if (processor == null || Kernel.TryGet<IBasicProcess<TCoreInput, TCoreOutput>>() != null) return;

            Kernel.Bind<IBasicProcess<TCoreInput, TCoreOutput>>().To(processor);

        }

        internal static void RegisterDefaultResponseGenerator<TCoreOutput>(Type defaultMessageGenerator)
        {
            if (defaultMessageGenerator == null || Kernel.TryGet<IDefaultResponseGenerator<TCoreOutput>>() != null) return;
            Kernel.Bind<IDefaultResponseGenerator<TCoreOutput>>().To(defaultMessageGenerator);
        }

        /// <summary>
        /// Register a ITypeConverter from TSource to TDestintation by Giving the type that implements the interface
        /// </summary>
        /// <typeparam name="TSource">The source to be converted</typeparam>
        /// <typeparam name="TDestination">the destination type of the conversion</typeparam>
        /// <param name="typeConverter">the class that implements ITypeConverter&lt;TSource, TDestination&gt;</param>
        internal static void RegisterTypeConverter<TSource, TDestination>(Type typeConverter)
            where TSource : class, new()
            where TDestination : class, new()
        {
            if (typeConverter == null || Kernel.TryGet<ITypeConverter<TSource, TDestination>>() != null) return;
            Kernel.Bind<ITypeConverter<TSource, TDestination>>().To(typeConverter);
        }
    }
}