﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using Com.Framework.Model.Exceptions;
using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Pipeline.Processors
{
    /// <summary>
    /// 
    /// </summary>
    public static class Utility
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="invokation"></param>
        /// <returns></returns>
        public static Invokation GenerateInvokationEnvironment(Invokation invokation)
        {
            //TODO:
            if (OperationContext.Current == null) return (invokation);
            MessageProperties messageProps = OperationContext.Current.IncomingMessageProperties;
            RemoteEndpointMessageProperty remoteEndProp = (RemoteEndpointMessageProperty)messageProps[RemoteEndpointMessageProperty.Name];
            HttpRequestMessageProperty httpProp = (HttpRequestMessageProperty)messageProps[HttpRequestMessageProperty.Name];

            var forwardHeader = httpProp.Headers["X-Forwarded-For"];


            invokation.SourceIp = forwardHeader ?? remoteEndProp.Address;
            invokation.ProxyIp = forwardHeader == null ? remoteEndProp.Address : null;
            invokation.ServingUrl = httpProp.QueryString;

            return (invokation);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="request"></param>
        public static void ValidateInput(object request)
        {
            if (request == null)
            {
                //throw new ArgumentNullException(nameof(request));
                throw new DataValidationErrorException("Please fill in your request", OperationErrorCodes.NullRequest);
            }
        }
    }
}
