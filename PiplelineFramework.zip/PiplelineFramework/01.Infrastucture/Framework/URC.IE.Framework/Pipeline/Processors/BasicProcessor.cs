﻿using System;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Com.Framework.Contract;
using Com.Framework.Model.Exceptions;
using Com.Framework.Model.Operation.Messages;
using log4net;

namespace Com.Framework.Pipeline.Processors
{
    /// <summary>
    /// Class that takes care of the coordination of validating inputs, authenticate,
    /// Converting from customer model to et model, process the request and ensure DB access
    /// </summary>
    /// <typeparam name="TRequest">Type of the request in customer model</typeparam>
    /// <typeparam name="TResponse">Type of the response in customer model</typeparam>
    /// <typeparam name="TDtoInput">Type of the request in model</typeparam>
    /// <typeparam name="TDtoOutput">Type of the response in model</typeparam>
    public class BasicProcessor<TRequest, TResponse, TDtoInput, TDtoOutput>
        : IFrontEndProcessor<TRequest, TResponse>
        where TRequest : BaseRequest, new()
        where TResponse : BaseResponse, new()
        where TDtoInput : BaseRequest, new()
        where TDtoOutput : BaseResponse, new()
    {
        private readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <param name="invokation"></param>
        /// <returns></returns>
        public TResponse ProcessRequest(TRequest request, Invokation invokation)
        {
            TResponse response;
            try
            {
                Log.InfoFormat(">>-------------------------------------------------{0}---------------------------------------------------", invokation.Invoker.Name);
                //Instead of rename the thread, we are going to use Log4Net Context Properties
                KeyFieldThreadRenamer.RenameLoggerContext(request, invokation.Invoker);

                //Get network information
                invokation = Utility.GenerateInvokationEnvironment(invokation);


                //Input Data validation
                IValidator<TRequest> inputValidator = PipeLineManager.GetValidator<TRequest>();

                //Covert the types
                ITypeConverter<TRequest, TDtoInput> inboundConverter = PipeLineManager.GetTypeConverter<TRequest, TDtoInput>();
                ITypeConverter<TDtoOutput, TResponse> outboundConverter = PipeLineManager.GetTypeConverter<TDtoOutput, TResponse>();


                //Looking up operation processor
                IBasicProcess<TDtoInput, TDtoOutput> processor = PipeLineManager.GetBasicProcessor<TDtoInput, TDtoOutput>();
                if (processor == null)
                {
                    throw new DevelopmentException($"Missing processor configuration!!!");
                }
                //Process the request
                response = processor.Process(request, inputValidator, inboundConverter, outboundConverter, invokation);

                Log.InfoFormat("<<-------------------------------------------------{0}---------------------------------------------------", invokation.Invoker.Name);

                return (response);

            }
            catch (BaseException ex)
            {
                Log.Error("Handled error", ex);
                IDefaultResponseGenerator<TResponse> defResponseGenerator = PipeLineManager.GetDefaultMessageGenerator<TResponse>();
                response = defResponseGenerator.GenerateDefaultResponse(ex);
            }
            catch (Exception ex)
            {
                Log.Error("Unhandled error during operation, sending default response", ex);
                IDefaultResponseGenerator<TResponse> defResponseGenerator = PipeLineManager.GetDefaultMessageGenerator<TResponse>();
                response = defResponseGenerator.GenerateDefaultResponse();
            }

            Log.InfoFormat("<<-------------------------------------Error--------{0}---------Error----------------------------------------", invokation.Invoker.Name);
            return (response);
        }




    }
}