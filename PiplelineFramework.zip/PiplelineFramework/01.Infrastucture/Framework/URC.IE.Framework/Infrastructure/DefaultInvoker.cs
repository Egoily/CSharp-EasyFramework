﻿namespace Com.Framework.Infrastructure
{
    /// <summary>
    /// 
    /// </summary>
    public class DefaultInvoker
    {
    }
}