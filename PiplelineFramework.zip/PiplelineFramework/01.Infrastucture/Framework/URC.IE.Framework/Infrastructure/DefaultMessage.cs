﻿using Com.Framework.Model.Enumeration;
using Com.Framework.Model.Exceptions;
using Com.Framework.Model.Operation.Messages;
using Com.Framework.Pipeline;

namespace Com.Framework.Infrastructure
{
    /// <summary>
    /// Default message
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class DefaultMessage<T> : IDefaultResponseGenerator<T> where T : BaseResponse, new()
    {/// <summary>
     /// 
     /// </summary>
     /// <returns></returns>
        public T GenerateDefaultResponse()
        {
            return DefaultMessage<T>.GenerateDefault();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static T GenerateDefault()
        {
            T defaultResponse = new T()
            {
                ResultType = ResultTypes.UnknownError,
                Code = -1,
                Message = "Unknown Error",
            };
            return (defaultResponse);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public static T GenerateOkResponse(T response)
        {
            response.Code = 0;
            response.ResultType = ResultTypes.Ok;
            response.Message = "successful";
            return (response);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        T IDefaultResponseGenerator<T>.GenerateDefaultResponse(BaseException ex)
        {
            T response = new T()
            {
                ResultType = ex.ResultType,
                Code = ex.ErrorCode,
                Message = ex.Message,
            };

            return response;
        }
    }
}