﻿using System.Reflection;
using Com.Framework.Model.Operation.Messages;
using Com.Framework.Pipeline;
using Com.Framework.Util;
using log4net;
using Newtonsoft.Json;


namespace Com.Framework.Infrastructure
{
    /// <summary>
    /// Helper class to invoke the pipeline providing the base types to ensure the restrictions on types apply
    /// </summary>
    public class BussinessOperationProcessor
    {
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// Process a request of TInput type, returning a TOutput
        /// </summary>
        /// <typeparam name="TInput">The type of the request</typeparam>
        /// <typeparam name="TOutput">The type of the response</typeparam>
        /// <param name="request">The data received of request</param>
        /// <param name="invoker"></param>
        /// <returns>The result (of type TOutput) of processing the request depending on the pipeline</returns>
        public static TOutput ProcessRequest<TInput, TOutput>(TInput request, Invokation invoker)
            where TInput : BaseRequest, new()
            where TOutput : BaseResponse, new()
        {
            //Get the linked operation processor for this types
            var processor = PipeLineManager.GetPipeline<TInput, TOutput>();


            if (processor == null)
            {
                Log.FatalFormat("The types input:{0} ouput:{1} are not configured in the pipeline!", typeof(TInput), typeof(TOutput));
                return (DefaultMessage<TOutput>.GenerateDefault());
            }

            TOutput response = processor.ProcessRequest(request, invoker);
            return response;
        }

        /// <summary>
        /// Process a request of TInput type, returning a ResponseObj
        /// </summary>
        /// <typeparam name="TInput">The type of the request</typeparam>
        /// <typeparam name="TOutput">The type of the response</typeparam>
        /// <param name="request">The data received of request</param>
        /// <param name="invoker"></param>
        /// <returns>The result (of type ResponseObj) of processing the request depending on the pipeline</returns>
        public static FormatResponse JsonProcessRequest<TInput, TOutput>(TInput request, Invokation invoker)
          where TInput : BaseRequest, new()
          where TOutput : BaseResponse, new()
        {
            var output = ProcessRequest<TInput, TOutput>(request, invoker);

            var data = string.Empty;
            if (output.Code == 0)
            {
                JsonSerializerSettings jsetting = new JsonSerializerSettings
                {
                    ContractResolver = new JsonPropsIgnoreContractResolver()
                };

                data = JsonConvert.SerializeObject(output, Formatting.None, jsetting);
            }
            var response = new FormatResponse()
            {
                Code = output.Code,
                Message = output.Message,
                Data = data,
                //Data = string.IsNullOrEmpty(data)? null :data,
            };
            return response;
        }

        /// <summary>
        /// Process a request of TInput type, returning a ResponseObj
        /// </summary>
        /// <typeparam name="TInput">The type of the request</typeparam>
        /// <typeparam name="TOutput">The type of the response</typeparam>
        /// <param name="request">The data received of request that type of Json</param>
        /// <param name="invoker"></param>
        /// <returns>The result (of type ResponseObj) of processing the request depending on the pipeline</returns>
        public static FormatResponse JsonProcessRequest<TInput, TOutput>(string request, Invokation invoker)
            where TInput : BaseRequest, new()
            where TOutput : BaseResponse, new()
        {
            var input = JsonConvert.DeserializeObject<TInput>(request);

            return JsonProcessRequest<TInput, TOutput>(input, invoker);
        }


    }
}