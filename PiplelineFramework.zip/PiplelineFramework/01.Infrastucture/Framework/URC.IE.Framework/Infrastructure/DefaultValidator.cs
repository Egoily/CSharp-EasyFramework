﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Com.Framework.Infrastructure
{
    /// <summary>
    ///Default Validator
    /// </summary>
    public class DefaultValidator
    {
       
    }
}