﻿using System.Collections.Generic;
using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Contract
{
    /// <summary>
    /// Interface to validate objects
    /// </summary>
    /// <typeparam name="T">the type of object to be validated</typeparam>
    public interface IValidator<in T>
    {
        /// <summary>
        /// Checks the validity of an object
        /// </summary>
        /// <param name="objectToValidate">the object that will be validated</param>
        /// <param name="messages"></param>
        /// <returns>a Boolean indicating if the object is valid or not</returns>
        bool Validate(T objectToValidate,List<string> messages);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="credential"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        bool Authorize(Credential credential,string message);
    }
}