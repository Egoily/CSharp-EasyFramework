﻿using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Contract
{
    /// <summary>
    /// Interface for business operations that can be invoked externaly by with a DTO model
    /// </summary>
    /// <typeparam name="TDtoInput">The type of the input parameter in the DTO form</typeparam>
    /// <typeparam name="TDtoOutput">The type of the output parameter in the DTO form</typeparam>

    public interface IBasicProcess<in TDtoInput, out TDtoOutput>
       where TDtoInput : BaseRequest
       where TDtoOutput : BaseResponse
    {
        /// <summary>
        /// Process a request in the customer form,
        /// </summary>
        /// <typeparam name="TRequest">The type of the request in DTO customer model</typeparam>
        /// <typeparam name="TResponse">The type of the response  in the DTO customer model</typeparam>
        /// <param name="request">the request in customer DTO model</param>
        /// <param name="validator">the validator for the request in customer model</param>
        /// <param name="inboundConverter">the ITypeConverter for the input request in DTO form to the DTO form</param>
        /// <param name="outboundConverter">the ITypeConverter for the output request in DTO from to the Customer DTO form</param>
        /// <param name="invokation">the request invokation environment</param>
        /// <returns>the result in customer model</returns>
        TResponse Process<TRequest, TResponse>(TRequest request, IValidator<TRequest> validator, ITypeConverter<TRequest, TDtoInput> inboundConverter, ITypeConverter<TDtoOutput, TResponse> outboundConverter, Invokation invokation)
                                                  where TRequest : BaseRequest, new()
                                                  where TResponse : BaseResponse, new();
    }
}