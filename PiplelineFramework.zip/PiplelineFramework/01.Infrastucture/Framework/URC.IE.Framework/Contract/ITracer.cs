﻿using System.Collections.Generic;
using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Contract
{
    /// <summary>
    /// 
    /// </summary>
    public interface ITracer
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        bool Log();
    }
}