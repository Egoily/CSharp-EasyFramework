﻿using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Contract
{
    /// <summary>
    /// Interface that all operations that may be invoked externally and internally must implement.
    /// </summary>
    /// <typeparam name="TDtoInput">The type of the request to be processed in DTO form</typeparam>
    /// <typeparam name="TDtoOutput">The type of the reponse as a result of the process in DTO form</typeparam>
    /// <typeparam name="TCoreInput">The type of the request to be processed in Internal/Core format</typeparam>
    /// <typeparam name="TCoreOutput">The type of the response in Internal/Core format</typeparam>
    public interface IBasicBizOp<in TDtoInput, out TDtoOutput, in TCoreInput, out TCoreOutput> : IBasicProcess<TDtoInput, TDtoOutput>
        where TDtoInput : BaseRequest
        where TDtoOutput : BaseResponse
        where TCoreInput : BaseRequest
        where TCoreOutput : BaseResponse
    {
    }
}