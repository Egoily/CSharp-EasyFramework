﻿using System;
using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Auth
{
    /// <summary>
    /// Helper class to check that a user can have access to the specified dealer
    /// </summary>
    public static class AuthorizationHelper
    {

        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        public static Boolean TryAuthorize(CredentialSoapHeader header)
        {
            throw new NotImplementedException();
        }

    }
}