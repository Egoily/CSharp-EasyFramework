﻿using System;
using Com.Framework.Model.Exceptions;

namespace Com.Framework.Auth
{
    /// <summary>
    /// Helper class to authenticate the credentials provided.
    /// </summary>
    public static class AuthenticationHelper
    {
        /// <summary>
        /// Provides the user authentication.
        /// </summary>
        /// <param name="user">the id of user</param>
        /// <param name="password">the password of user</param>
        /// <exception cref="AuthenticationErrorException"> Thrown if user is invalid.</exception>
        /// <returns>if success, return the user entity. otherwise, will throw exceptions.</returns>
        public static void Authenticate(string user, string password)
        {
            throw new NotImplementedException();
        }
    }
}