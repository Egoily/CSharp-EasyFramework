﻿using System;
using System.Runtime.Serialization;
using Com.Framework.Model.Enumeration;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    /// The base class/type for all the bussiness operations in the internal form
    /// </summary>
    [DataContract(Namespace = Declarations.NameSpace)]
    [Serializable]
    public class BaseResponse
    {
        /// <summary>
        /// The result type of the operation
        /// </summary>
        [DataMember]
        [JsonConverter(typeof(StringEnumConverter))]
        [JsonPropIgnoreAttibute]
        public ResultTypes ResultType { get; set; }

        /// <summary>
        /// The code of the opertaion
        /// </summary>
        [DataMember]
        [JsonPropIgnoreAttibute]
        public int Code { get; set; }

        /// <summary>
        /// Set of messages explaining the result of the operation
        /// </summary>
        [DataMember]
        [JsonPropIgnoreAttibute]
        public string Message { get; set; }
    }

}