﻿using System.Web.Services.Protocols;

namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    /// 
    /// </summary>
    public class CredentialSoapHeader : SoapHeader
    {
        public Credential Credential { get; set; }

        public CredentialSoapHeader()
        {
            Credential = null;
        }

        public CredentialSoapHeader(string username, string password)
        {
            Credential.UserName = username;
            Credential.Password = password;
        }
        public CredentialSoapHeader(Credential credential)
        {
            Credential = credential;
        }


    }
}