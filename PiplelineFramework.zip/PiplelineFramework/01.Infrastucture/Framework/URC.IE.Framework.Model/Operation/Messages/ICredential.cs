﻿namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    /// 
    /// </summary>
    public interface ICredential
    {

        /// <summary>   
        /// UserName   
        /// </summary>   
        string UserName { get; set; }

        /// <summary>   
        /// Password
        /// </summary>   
        string Password { get; set; }


    }
}