﻿using System.Runtime.Serialization;

namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    /// 
    /// </summary>
    public interface IPagination
    {
        /// <summary>
        /// the index of the page
        /// </summary>
        [DataMember]
        int PageIndex { get; set; }
        /// <summary>
        /// the size of the page
        /// </summary>
        [DataMember]
        int PageSize { get; set; }
    }
}
