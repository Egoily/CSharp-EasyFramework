﻿using System.Reflection;

namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    /// Class that holds network information for incoming requests and the MethodInfo for the request received.
    /// </summary>
    public class Invokation
    {
        /// <summary>
        /// The front end method that received the
        /// </summary>
        public MethodBase Invoker { get; set; }
        /// <summary>
        /// Credential Soap Header
        /// </summary>
        public Credential Credential { get; set; }

        /// <summary>
        /// Source Up that sent the request
        /// </summary>
        public string SourceIp { get; set; }

        /// <summary>
        /// Proxy/Load Balancer Ip address
        /// </summary>
        public string ProxyIp { get; set; }

        /// <summary>
        /// The Ip that received the request
        /// </summary>
        public string DestinationIp { get; set; }

        /// <summary>
        /// Url to which the request was sent.
        /// </summary>
        public string ServingUrl { get; set; }
        /// <summary>
        /// Executor
        /// </summary>
        public string Executor { get; set; }
    }
}