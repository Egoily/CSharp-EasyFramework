﻿using System;
using System.Runtime.Serialization;

namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    /// The base class for any request
    /// </summary>
    ///
    [DataContract(Namespace = Declarations.NameSpace)]
    [Serializable]
    public class BaseRequest
    {

    }



}