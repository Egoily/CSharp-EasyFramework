﻿namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    /// 
    /// </summary>
    public class Credential: ICredential
    {
        /// <summary>   
        /// UserName   
        /// </summary>   
        public string UserName { get; set; } = string.Empty;

        /// <summary>   
        /// Password
        /// </summary>   
        public string Password { get; set; } = string.Empty;

        public Credential()
        {

        }
        public Credential(string userName, string password)
        {
            this.UserName = userName;
            this.Password = password;
        }

    }
}