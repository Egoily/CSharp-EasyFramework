﻿using System;
using System.Runtime.Serialization;

namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    ///
    /// </summary>
    [DataContract(Namespace = Declarations.NameSpace)]
    [Serializable]
    public class FormatResponse
    {
        /// <summary>
        /// Operation result code
        /// </summary>
        [DataMember]
        public int Code { get; set; }

        /// <summary>
        /// Shown message
        /// </summary>
        [DataMember]
        public string Message { get; set; }
        /// <summary>
        /// the format type for Data
        /// </summary>
        [DataMember]
        public string FormatType { get; set; }
        /// <summary>
        ///  objects typing of string
        /// </summary>
        [DataMember]
        public string Data { get; set; }
    }
}