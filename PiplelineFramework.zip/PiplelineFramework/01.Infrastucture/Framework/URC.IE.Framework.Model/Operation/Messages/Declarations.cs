﻿using System;

namespace Com.Framework.Model.Operation.Messages
{
    /// <summary>
    /// 
    /// </summary>
    public class Declarations
    {
        public const string NameSpace = @"http://www.example.com";
    }
}