﻿using System;

namespace Com.Framework.Model
{
    /// <summary>
    /// 
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class SecurityFieldAttibute : Attribute
    {
    }
}
