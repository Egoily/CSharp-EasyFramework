﻿using System.Runtime.Serialization;
using Com.Framework.Model.Operation.Messages;

namespace Com.Framework.Model.Enumeration
{
    /// <summary>
    /// Enumerated of all the error types handled by the platform
    /// </summary>
    [DataContract(Namespace = Declarations.NameSpace)]
    public enum ResultTypes
    {
        /// <summary>
        /// The operation was successfull
        /// </summary>
        [EnumMember]
        Ok = 0,

        /// <summary>
        /// The validation of the request failed
        /// </summary>
        [EnumMember]
        DataValidationError = 1,

        /// <summary>
        /// The request has been queued
        /// </summary>
        [EnumMember]
        Queued = 2,

        /// <summary>
        /// The request could not be processed due to bussiness or logic errors
        /// </summary>
        [EnumMember]
        BussinessLogicError = 3,

        /// <summary>
        /// An unhandled error happened
        /// </summary>
        [EnumMember]
        UnknownError = 4,

        /// <summary>
        /// Could not authenticate the username/password combination
        /// </summary>
        [EnumMember]
        AuthenticationError = 5,

        /// <summary>
        /// The user given did not had permissions to perform the operation
        /// </summary>
        [EnumMember]
        AuthorizationError = 6,
    }
}