﻿using System;

namespace Com.Framework.Model
{
    /// <summary>
    /// 
    /// </summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property | AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Interface | AttributeTargets.Enum | AttributeTargets.Parameter, AllowMultiple = false)]
    public sealed class JsonPropIgnoreAttibute : Attribute
    {
        public JsonPropIgnoreAttibute()
        {
        }

    }
}
