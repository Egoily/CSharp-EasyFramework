﻿using System;
using Com.Framework.Model.Enumeration;

namespace Com.Framework.Model.Exceptions
{
    /// <summary>
    /// Handled exception at framework level produced by an exception that is not an elephant talk exception
    /// </summary>
    public class InternalErrorException : BaseException
    {
        /// <summary>
        /// The result type associeated to this type of exception (ResultTypes.UnknownError)
        /// </summary>
        public override ResultTypes ResultType => ResultTypes.UnknownError;

        /// <summary>
        /// Constructor for exception providing error message and error code
        /// </summary>
        /// <param name="message">the message with the cause for the exception</param>
        /// <param name="errorCode">the error code for the exception</param>
        public InternalErrorException(string message, int errorCode) : base(message, errorCode) { }

        /// <summary>
        /// Constructor for exception providing error message and error code and the inner exception that caused the error
        /// </summary>
        /// <param name="message">the message with the cause for the exception</param>
        /// <param name="ex">the inner exception that rised this exception</param>
        /// <param name="errorCode">the error code for the exception</param>
        public InternalErrorException(string message, Exception ex, int errorCode) : base(message, ex, errorCode) { }
    }
}