﻿using System;
using Com.Framework.Model.Enumeration;

namespace Com.Framework.Model.Exceptions
{
    /// <summary>
    /// Abstract class for operations, all Exceptions needs to inherit from this class.
    /// </summary>
    [Serializable]
    public abstract class BaseException : Exception
    {
        /// <summary>
        /// Error code of the exception
        /// </summary>
        public int ErrorCode { get; set; }

        /// <summary>
        /// ResultType for the exception.
        /// </summary>
        public abstract ResultTypes ResultType { get; }

        /// <summary>
        /// Constructor providing a message and an error code
        /// </summary>
        /// <param name="message">Message of the exception</param>
        /// <param name="errorCode">Error code of the exception</param>
        protected BaseException(string message, int errorCode) : base(message) { this.ErrorCode = errorCode; }

        /// <summary>
        /// onstructor providing a message and an error code
        /// </summary>
        /// <param name="message">Message of the exception</param>
        /// <param name="ex">Inner exception that triggerd this exception</param>
        /// <param name="errorCode">Error code of the exception</param>
        protected BaseException(string message, Exception ex, int errorCode) : base(message, ex) { ErrorCode = errorCode; }
    }
}