﻿using System;
using Com.Framework.Model.Enumeration;

namespace Com.Framework.Model.Exceptions
{
    /// <summary>
    /// Exception thrown when there is an authentication problem
    /// Missing user or password, incorrect user name password combination...
    /// </summary>
    public class AuthenticationErrorException : BaseException
    {
        /// <summary>
        /// Indicates the type/category of the error
        /// </summary>
        public override ResultTypes ResultType => ResultTypes.AuthenticationError;

        /// <summary>
        /// Constructor for exception providing error message and error code
        /// </summary>
        /// <param name="message">the message with the cause for the exception</param>
        /// <param name="errorCode">the error code for the exception</param>
        public AuthenticationErrorException(string message, int errorCode) : base(message, errorCode) { }

        /// <summary>
        /// Constructor for exception providing error message and error code and the inner exception that caused the error
        /// </summary>
        /// <param name="message">the message with the cause for the exception</param>
        /// <param name="ex">the inner exception that rised this exception</param>
        /// <param name="errorCode">the error code for the exception</param>
        public AuthenticationErrorException(string message, Exception ex, int errorCode) : base(message, ex, errorCode) { }
    }
}