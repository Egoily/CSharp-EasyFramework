﻿using System;
using Com.Framework.Model.Enumeration;

namespace Com.Framework.Model.Exceptions
{
    /// <summary>
    /// Exception thrown when the user has not permissions to operate a given entity
    /// </summary>
    public class AuthorizationErrorException : BaseException
    {
        /// <summary>
        /// The result type associated to this exception
        /// </summary>
        public override ResultTypes ResultType
        {
            get { return ResultTypes.AuthorizationError; }
        }

        /// <summary>
        /// Constructor for exception providing error message and error code
        /// </summary>
        /// <param name="message">the message with the cause for the exception</param>
        /// <param name="errorCode">the error code for the exception</param>
        public AuthorizationErrorException(string message, int errorCode) : base(message, errorCode) { }

        /// <summary>
        /// Constructor for exception providing error message and error code and the inner exception that caused the error
        /// </summary>
        /// <param name="message">the message with the cause for the exception</param>
        /// <param name="ex">the inner exception that rised this exception</param>
        /// <param name="errorCode">the error code for the exception</param>
        public AuthorizationErrorException(string message, Exception ex, int errorCode) : base(message, ex, errorCode) { }
    }
}