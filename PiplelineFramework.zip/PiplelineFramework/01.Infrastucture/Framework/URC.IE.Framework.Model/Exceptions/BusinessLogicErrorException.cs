﻿using System;
using Com.Framework.Model.Enumeration;

namespace Com.Framework.Model.Exceptions
{
    /// <summary>
    /// Exceptions that operation throws in case of business logic error
    /// </summary>
    public class BusinessLogicErrorException : BaseException
    {
        /// <summary>
        /// The result type associated to this exception
        /// </summary>
        public override ResultTypes ResultType => ResultTypes.BussinessLogicError;

        /// <summary>
        /// Constructor for exception providing error message and error code
        /// </summary>
        /// <param name="message">the message with the cause for the exception</param>
        /// <param name="errorCode">the error code for the exception</param>
        public BusinessLogicErrorException(string message, int errorCode) : base(message, errorCode) { }

        /// <summary>
        /// Constructor for exception providing error message and error code and the inner exception that caused the error
        /// </summary>
        /// <param name="message">the message with the cause for the exception</param>
        /// <param name="ex">the inner exception that rised this exception</param>
        /// <param name="errorCode">the error code for the exception</param>
        public BusinessLogicErrorException(string message, Exception ex, int errorCode) : base(message, ex, errorCode) { }
    }
}