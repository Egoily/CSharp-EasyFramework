﻿using System;
using System.Transactions;

namespace URC.IE.Framework.Data
{
    public class NoLockHelper
    {
        public static void QueryWithNoLock(Action action)
        {
            var transactionOptions = new TransactionOptions();
            transactionOptions.IsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted;
            using (var transactionScope = new TransactionScope(TransactionScopeOption.Required, transactionOptions))
            {
                try
                {
                    action();
                }
                finally
                {
                    transactionScope.Complete();
                }
            }
        }
    }

   
}