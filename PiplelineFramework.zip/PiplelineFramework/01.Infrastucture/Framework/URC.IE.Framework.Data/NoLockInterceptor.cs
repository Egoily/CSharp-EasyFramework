﻿using log4net;
using System;
using System.Data;
using System.Data.Common;
using System.Data.Entity.Infrastructure.Interception;
using System.Reflection;
using System.Text.RegularExpressions;

namespace URC.IE.Framework.Data
{
    public class NoLockInterceptor : DbCommandInterceptor
    {
        /// <summary>
        /// Logger
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        private static readonly Regex _tableAliasRegex = new Regex(@"(?<tableAlias>AS \[Extent\d+\](?! WITH \(NOLOCK\)))", RegexOptions.Multiline | RegexOptions.IgnoreCase);

        [ThreadStatic]
        public static bool SuppressNoLock;

        public override void ScalarExecuting(DbCommand command, DbCommandInterceptionContext<object> interceptionContext)
        {
            if (!SuppressNoLock)
            {
                command.CommandText = _tableAliasRegex.Replace(command.CommandText, "${tableAlias} WITH (NOLOCK)");

            }
            OutputSql(command);
        }

        private static void OutputSql(DbCommand command)
        {
            try
            {
                if (Log.IsDebugEnabled)
                {
                    var sql = command.CommandText;
                    for (var i = 0; i < command.Parameters.Count; i++)
                    {
                        var parameter = command.Parameters[i];
                        var parameterName = parameter.ParameterName.Contains("@")
                            ? parameter.ParameterName
                            : $"@{parameter.ParameterName}";

                        string sqlValue;
                        if (parameter.DbType == DbType.Int16
                            || parameter.DbType == DbType.Int32
                            || parameter.DbType == DbType.Int64
                            || parameter.DbType == DbType.UInt16
                            || parameter.DbType == DbType.UInt32
                            || parameter.DbType == DbType.UInt64
                            || parameter.DbType == DbType.Decimal
                            || parameter.DbType == DbType.Double
                            || parameter.DbType == DbType.VarNumeric
                            )
                        {
                            sqlValue = parameter.Value.ToString();
                        }
                        else
                        {
                            sqlValue = $"'{parameter.Value}'";
                        }
                        sql = sql.Replace(parameterName, sqlValue);

                    }

                    Log.Debug($"\n{sql}\n");

                }
            }
            catch (Exception ex)
            {
                Log.Error("Error on Output Sql script",ex);
            }
           
        }

        public override void ReaderExecuting(DbCommand command, DbCommandInterceptionContext<DbDataReader> interceptionContext)
        {
            if (!SuppressNoLock)
            {
                command.CommandText = _tableAliasRegex.Replace(command.CommandText, "${tableAlias} WITH (NOLOCK)");
            }
            OutputSql(command);

        }
        public override void NonQueryExecuting(DbCommand command, DbCommandInterceptionContext<int> interceptionContext)
        {
            base.NonQueryExecuting(command, interceptionContext);
            OutputSql(command);
        }

    }
}
